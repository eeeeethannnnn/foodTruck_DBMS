public class Configuration {
    public static String username;
    public static String userType;
    public static String chosenStationName;
    public static String chosenBuildingName;
    public static String chosenFoodTruck;
}
